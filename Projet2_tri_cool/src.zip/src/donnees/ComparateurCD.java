package donnees;

public interface ComparateurCD {

    public boolean etreAvant(CD cd1, CD cd2);

}
